// ==UserScript==
// @name        Remove Youtube Ads
// @namespace   PXgamer
// @description Remove ads
// @include     *youtube.com/*
// @version     1
// @grant       none
// ==/UserScript==

document.cookie="VISITOR_INFO1_LIVE=oKckVSqvaGw; path=/; domain=.youtube.com";