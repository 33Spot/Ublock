// ==UserScript==
// @name        pornhub.com All Video Downloader(even premium)
// @namespace   Violentmonkey Scripts
// @match       https://xxxsave.net/
// @include     *pornhub.com/*
// @include     https://xxxsave.net
// @grant       GM_setValue
// @grant       GM_getValue
// @grant       none
// @version     1.3
// @author      -
// @require     https://code.jquery.com/jquery-3.5.1.min.js
// @description 9.4.2021, 15:25:34

// ==/UserScript==
var downloadButtonUnderTitel = true; // replace "true" to "false" if you only want the button in the custom created tab "download" and remove the button under the title

if (window.location.href.indexOf("pornhub.com") != -1){
  $("document").ready(function() {
    var tabs = document.getElementsByClassName('video-actions-tabs')[0];
    var tab = document.createElement('div');
    tab.className = 'video-action-tab my-custom-tab';
    tabs.appendChild(tab);
    var btn = document.createElement("BUTTON");
    btn.innerHTML = "Download";
    btn.className = "orangeButton filterBtn removeAdLink";
    btn.onclick = download;
    tab.appendChild(btn);
    
    var menu = document.getElementsByClassName('tab-menu-wrapper-row')[0];
    var newItem = document.createElement('div');
    var sub = document.createElement('div');
    var icon = document.createElement('i');
    var text = document.createElement('span');
    text.innerText = 'Download';
    icon.className = 'main-sprite-dark-2';
    sub.className = 'tab-menu-item tooltipTrig';
    sub.dataset.title = 'Download (Script)';
    sub.dataset.tab = 'my-custom-tab';
    sub.appendChild(icon);
    sub.appendChild(text);
    newItem.className = 'tab-menu-wrapper-cell';
    newItem.appendChild(sub);
    menu.appendChild(newItem);
    
    if(downloadButtonUnderTitel){
      var btn2 = document.createElement("BUTTON");
      btn2.innerHTML = "Download";
      btn2.className = "orangeButton filterBtn removeAdLink";
      btn2.onclick = download;
      document.getElementsByClassName("title-container")[0].appendChild(btn2); 
    }
  });
  
}else{
  $("document").ready(async function() {
    var url = GM_getValue('phvideokey');
    document.getElementsByName("url")[0].value = url;
    
     var checkButtonExist = setInterval(function() {
       if (document.getElementById("bsubmit") != null) {
          document.getElementById("bsubmit").click();
          clearInterval(checkButtonExist);
       }
    }, 1000);
    var checkExist = setInterval(function() {
       if (document.getElementsByClassName("dlink")[0].href != "https://xxxsave.net/#") {
          //forceDownload(document.getElementsByClassName("dlink")[0].href,  GM_getValue('phvideoname') + ".mp4"); 
          clearInterval(checkExist);
          window.location = document.getElementsByClassName("dlink")[0].href;
       }
    }, 1000);
  });
}


function download(){
    GM_setValue('phvideokey', window.location);
    GM_setValue('phvideoname', document.getElementsByClassName("title translate canTranslate")[0].children[0].innerText); 
    window.open("https://xxxsave.net");
}
function sleep(milliseconds) {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
}

async function forceDownload(url, fileName){ // workes as well but does not show download progess so i did not bother doing it this way
    console.log("Loading: " + url);
    var out = 1;
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.responseType = "blob";
    xhr.onload = function(){
        if(this.response.type == "text/html"){
            console.log(this.response);
            out = 2;
            return;
        }
        var urlCreator = window.URL || window.webkitURL;
        var imageUrl = urlCreator.createObjectURL(this.response);
        var tag = document.createElement('a');
        tag.href = imageUrl;
        
        tag.download = fileName;
        document.body.appendChild(tag);
        tag.click();
        document.body.removeChild(tag);
    }
    await xhr.send();
    return out;
}