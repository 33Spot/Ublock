// ==UserScript==
// @name           Remove Allegro ads
// @name:pl        Usuwanie reklam Allegro
// @namespace      http://tampermonkey.net/
// @version        0.5.2
// @description    Aims to remove all Allegro ads not blocked by regular ad blockers, like "Sponsorowane produkty" and "sponsorowane" ad boxes.
// @description:pl Usuwa wszystkie reklamy Allegro, które nie są blokowane przez zwykłe blokery reklam, np. "Sponsorowane produkty" i "sponsorowane" boksy.
// @author         adamaru
// @match          *://allegro.pl/*
// @grant          none
// ==/UserScript==

(function() {
    'use strict';
    var running = false;

    function removeAllegroAds(mutations){
        if(mutations){
            var ignoreMutation = false;
            // skip removing ads when changes were made only to countdowns
            mutations.forEach(function(mutation) {
                var i, node;

                for (i = 0; i < mutation.addedNodes.length; i++) {
                    node = mutation.addedNodes[i];
                    if(!node.className || node.className.indexOf('countdown') !== -1){
                        ignoreMutation = true;
                        return;
                    }
                }

                for (i = 0; i < mutation.removedNodes.length; i++) {
                    node = mutation.removedNodes[i];
                    if(!node.className || node.className.indexOf('countdown') !== -1){
                        ignoreMutation = true;
                        return;
                    }
                }
            });
            if(ignoreMutation){
                // only countdown changes, skip
                return;
            }
        }

        if(running){
            // already running, skip
            return;
        }
        running = true;

		removeAllegroPremiumAds();
        removeAllegroOfferAds();
        removeAllegroSponsoredAds();
		removeAllegroAdArticles();

        running = false;
    }

    function removeAllegroOfferAds(){
        var adsBoxes = document.querySelectorAll('div[data-box-name*="_ads"]');
        for(var i = 0; i < adsBoxes.length; ++i){
            if(adsBoxes[i].style.display === "none"){
                continue;
            }
            adsBoxes[i].style.display = "none";
        }
    }

    function removeAllegroSponsoredAds(){
        var spansToCheck = document.querySelectorAll('section[class^="_"] > div[class]');
        for(var i = 0; i < spansToCheck.length; ++i){
            if(spansToCheck[i].innerHTML.indexOf('sponsorowane') !== -1){
				if(spansToCheck[i].parentNode.style.display === "none"){
					continue;
				}
                spansToCheck[i].parentNode.style.display = "none";
            }
        }
    }

    function removeAllegroAdArticles(){
        var adArticles = document.querySelectorAll('article[data-analytics-view-label="showSponsoredItems"]');
        for(var i = 0; i < adArticles.length; ++i){
			if(adArticles[i].style.display === "none"){
				continue;
			}
            adArticles[i].style.display = "none";
        }
    }

	function removeAllegroPremiumAds(){
		var premiumAds = document.querySelectorAll('div[data-box-name="premium.with.dfp"]');
        for(var i = 0; i < premiumAds.length; ++i){
			if(premiumAds[i].style.display === "none"){
				continue;
			}
            premiumAds[i].style.display = "none";
        }
	}

    removeAllegroAds(null);

    var observer = new MutationObserver(removeAllegroAds);
    var config = {childList: true, subtree: true};
    observer.observe(document.body, config);
})();