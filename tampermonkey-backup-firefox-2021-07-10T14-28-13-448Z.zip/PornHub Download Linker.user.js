// ==UserScript==
// @name        PornHub Download Linker
// @namespace   http://ghkgghgkhgkhh.com
// @include     https://*.pornhub.com/view_video.php*
// @include     https://pornhub.com/view_video.php*
// @version     2.4.4
// @grant       GM_xmlhttpRequest
// @description Download videos directly from pornhub.com
// ==/UserScript==

function getM3UData(u, ba, d){
	if (typeof GM_xmlhttpRequest !== 'undefined') {
		var details = GM_xmlhttpRequest({
		synchronous:true,
		method:"GET",
		url:u,
		headers:{
			"User-Agent":"Mozilla/5.0 (Windows NT 6.1; rv:70.0) Gecko/20100101 Firefox/70.0",
			"Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
		},
	});
	var m3u = new String(details.responseText);
	m3u =	ba+m3u.match(/index-.+$/m);
	if (m3u != null && m3u != "" && m3u.indexOf("http")!=-1) {
		var c = document.createElement("div");
		c.id = "m3u8_"+d;
		c.style='display: block; z-index:10001 !important; font-size:108%; line-height:108%; color: #ffffff; background-color: #222222; border: 2px solid #7f7ebe; margin-left: auto; margin-right:auto; text-align:center; font-weight:bold;'
		c.innerHTML = "<a id='a_m3ulist_"+c.id+"' href='"+m3u+"' style='margin-right:auto; margin-left:auto; align:center;'>Get "+ d +" M3U8 Video Links</a>"
	document.body.insertBefore(c, document.body.firstChild);
		var a2 = document.createElement("a");
		a2.id = "a_"+c.id;
		a2.style = "display:block!important;cursor:pointer;";
		a2.textContent = "Click To Pop-Up Modal With Video Links";
		c.appendChild(a2);
	}
 }
}

function addLinkElement(_l, _d) {
  if (_l.indexOf("master.m3u8")!=-1) {
	getM3UData(_l, _l.split("master.m3u8")[0], _d);
  } else {
	_d = _d + " Video";
	if (_l != null && _l != "" && _l.indexOf("http")!=-1) {
		var c = document.createElement("div");
		c.style='display: block; z-index:10001 !important; font-size:108%; line-height:108%; color: #ffffff; background-color: #222222; border: 2px solid #7f7ebe; margin-left: auto; margin-right:auto; text-align:center; font-weight:bold;'
		c.innerHTML = "<a href='"+_l+"' style='margin-right:auto; margin-left:auto; align:center;'>Download "+ _d +"</a>"
document.body.insertBefore(c, document.body.firstChild);
	}
  }
}


var vcServerUrl = null;
var player = document.getElementById("player");
var playerscript = player.getElementsByTagName("script")[0];
var psi = playerscript.innerHTML;
var _vcI = psi.indexOf('"vcServerUrl"');
var _vc = psi.substring(_vcI).split(",")[0];
var _vcNew = eval(JSON.parse("{"+_vc+"}"));
var _eva_text = "(function(){ var quality_240p, quality_480p, quality_720p, quality_1080p, media_0, media_1, media_2, media_3 = null; var playerObjList = {}; " + psi + "if (quality_240p==null){quality_240p=media_0} if (quality_480p==null){quality_480p=media_1}  if (quality_720p==null){quality_720p=media_2}  if (quality_1080p==null){quality_1080p=media_3}" + "return [quality_240p, quality_480p, quality_720p, quality_1080p]; })();";
var _eva4 = eval(_eva_text);

var na = new Array ("1080", "720", "480", "240");
var _count = 0;

for (_e in _eva4) {
	if (_count>=na.length*2) {
		break;
	}
	var _Case = null;
	if (typeof _eva4[_e] !== 'undefined') {
	  if (_eva4[_e] !== null) {
		for (_na in na) {
		var _regexp = new RegExp("\/"+na[_na]);
		  if (_eva4[_e].match(_regexp)) {
			_Case = na[_na];
			break;
		  }
		}
		if (_Case==null) {
			for (_na in na) {
			 var _regexp = new RegExp("_"+na[_na]+"p_","i");
			 if (_eva4[_e].match(_regexp)) {
			   _Case = na[_na];
			   break;
			 }
			}
		}
	  }
	}
 addLinkElement(unescape(_eva4[_e]), _Case+"p");
_count+=1;
}
	
vcServerUrl = unescape(_vcNew.vcServerUrl);
if (vcServerUrl !== null) {
	var greqURL = "https://www.pornhub.com" + vcServerUrl.toString();
	if (typeof GM_xmlhttpRequest !== 'undefined') {
	  GM_xmlhttpRequest({
		synchronous:false,
		method:"GET",
		url:greqURL,
		headers:{
			"User-Agent": "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)",
			"Accept":"application/xml, application/json"
		},
	});
  }
}

function DownloadBlob(res) {
	var listsrc = document.getElementById("a_m3ulist_m3u8_"+res).href;
	if (typeof GM_xmlhttpRequest !== 'undefined') {
		var details = GM_xmlhttpRequest({
		synchronous:true,
		method:"GET",
		url:listsrc,
		headers:{
			"User-Agent":"Mozilla/5.0 (Windows NT 6.1; rv:70.0) Gecko/20100101 Firefox/70.0",
			"Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
			},
		});
		var filelist = new String(details.responseText);
		var bloblinks = filelist.match(/^seg-.+$/gm);
		var D2 = document.createElement("div");
		var CB = document.createElement("div");
		CB.innerHTML="<p>Close Modal</p>";
		CB.setAttribute("id","modalclosebutton");
		CB.setAttribute("style","z-index:33002;cursor:pointer;");
		D2.appendChild(CB);
		var BR = document.createElement("br");
		D2.setAttribute("id","modalbody");
		D2.appendChild(BR);
		var C=1;
		for (var bl in bloblinks) {
			var newu = listsrc.split("index-")[0]+bloblinks[bl];
			var Desc = "Part "+C.toString();
			var A2 = document.createElement("a");
			var BR = document.createElement("br");
			A2.setAttribute("href",newu);
			A2.textContent=Desc;
			D2.appendChild(A2);
			D2.appendChild(BR);
			C+=1
		}
		var D3 = document.createElement("div");
		var BR = document.createElement("br");
		D3.setAttribute("id","modalcontainer");
		D2.appendChild(BR);
		D2.setAttribute("style","color:white;margin-left:auto;margin-right:auto;width:250px;max-width:250px;background-color:black;z-index:33001!important;border: 1px solid blue;display:block!important;")
		D3.appendChild(D2);
		D3.setAttribute("style","background: rgba(76, 75, 80, 0.9);position:absolute!important;top:0!important;left:0!important;z-index:33001!important;width:100%;height:auto;");
		document.body.appendChild(D3);
		document.getElementById("modalclosebutton").addEventListener("click", CloseModal);
	}
}

function DownloadBlob240() {
	var size="240p";
	DownloadBlob(size);
}

function DownloadBlob480() {
	var size="480p";
	DownloadBlob(size);
}

function DownloadBlob720() {
	var size="720p";
	DownloadBlob(size);
}

function DownloadBlob1080() {
	var size="1080p";
	DownloadBlob(size);
}

function CloseModal() {
	document.getElementById("modalcontainer").setAttribute("style","display:none!important;z-index:0!important;")
}
document.getElementById("a_m3u8_240p").addEventListener("click", DownloadBlob240);
document.getElementById("a_m3u8_480p").addEventListener("click", DownloadBlob480);
document.getElementById("a_m3u8_720p").addEventListener("click", DownloadBlob720);
document.getElementById("a_m3u8_1080p").addEventListener("click", DownloadBlob1080);
