// ==UserScript==
// @name     GmailのMeet/Chat非表示化
// @version  1
// @grant    none
// @include  https://mail.google.com/mail/*
// ==/UserScript==

(function () {
  setInterval(function() {
    let menu = document.getElementsByClassName('ajl')[0];
    let footer = document.getElementsByClassName('akc')[0];
    if (menu && footer) {
      menu.style.height = (parseInt(menu.style.height) + parseInt(footer.style.height)) + 'px';
      footer.style.height = '0px';
    }
  }, 100);
})();
