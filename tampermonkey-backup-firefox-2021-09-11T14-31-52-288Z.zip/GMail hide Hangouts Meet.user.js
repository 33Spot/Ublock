// ==UserScript==
// @name         GMail hide Hangouts Meet
// @namespace    http://tampermonkey.net/
// @version      0.2
// @description  Hide the Google Hangouts Meet section in GMail
// @author       Mark Montague <markmont@umich.edu>
// @match        https://mail.google.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Based on https://gist.github.com/Getsumi3/73dda56d40a726b4991d927699ecd83f
    function addGlobalStyle(css) {
        var head = document.getElementsByTagName("head")[0];
        if (!head) { return; }
        var style = document.createElement("style");
        style.type = "text/css";
        style.innerHTML = css;
        head.appendChild(style);
    }

    // Turn off default Hangouts Meet:
    addGlobalStyle("div[aria-label='Hangouts'] > div { display: none; }");

    // Turn off Hangouts Meet when Settings -> Chat is set to "off":
    addGlobalStyle(".akc.aZ6.YX { display: none; }");

})();