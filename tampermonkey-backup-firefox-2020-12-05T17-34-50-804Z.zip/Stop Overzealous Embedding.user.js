// ==UserScript==
// @name         Stop Overzealous Embedding
// @namespace    https://greasyfork.org/en/scripts/370-stop-overzealous-embedding
// @description  Tries to turn embedded Youtube videos into links
// @include      http://*
// @include      https://*
// @exclude      *.youtube.com/*
// @version      2.1
// ==/UserScript==

// Original namespace was http://userscripts.org/scripts/show/113484
(function() {
  "use strict";

  const riskyTags = ["object", "embed", "iframe"];

  function init(riskyElements) {
    let badElements = [];
    let badIds = [];

    if (riskyElements === null) {
      riskyElements = document.querySelectorAll(riskyTags.join(", "));
    }

    for (let j = 0; j < riskyElements.length; j++) {
      if (riskyTags.indexOf(riskyElements[j].nodeName.toLowerCase()) === -1) {
        continue;
      }

      let index = 0;
      const riskyAttributes = riskyElements[j].attributes;
      for (let k = 0; k < riskyAttributes.length; k++) {
        const riskyNode = riskyAttributes[k].nodeValue;
        if (
          riskyNode.indexOf("youtube.com") >= 0 ||
          riskyNode.indexOf("ytimg.com") >= 0 ||
          riskyNode.indexOf("youtube-nocookie.com") >= 0
        ) {
          riskyElements[j].style.display = "none";
          if (riskyNode.indexOf("/v/") >= 0) {
            index = riskyNode.indexOf("/v/") + 3;
          } else if (riskyNode.indexOf("?v=") >= 0) {
            index = riskyNode.indexOf("?v=") + 3;
          } else if (riskyNode.indexOf("/embed/") >= 0) {
            index = riskyNode.indexOf("/embed/") + 7;
          }
          if (index > 0) {
            const videoId = riskyNode.substring(index, index + 11);
            badElements.push(riskyElements[j]);
            badIds.push(videoId);
          }
          break;
        }
      }
    }

    for (let i = 0; i < badIds.length; i++) {
      const videoId = badIds[i];
      const videoUrl = "https://www.youtube.com/watch?v=" + videoId;
      const videoLink = document.createElement("a");
      videoLink.innerHTML = videoUrl;
      videoLink.setAttribute("href", videoUrl);
      badElements[i].parentNode.replaceChild(videoLink, badElements[i]);
    }
  }

  function timerCallback(riskyElements) {
    init(riskyElements);
  }

  function initCallback(mutations) {
    for (let i = 0; i < mutations.length; i++) {
      let riskyElements = [];
      let mutationNodes = mutations[i].addedNodes;
      if (!mutationNodes) {
        continue;
      }

      for (let j = 0; j < mutationNodes.length; j++) {
        if (
          mutationNodes[j].nodeName &&
          riskyTags.indexOf(mutationNodes[j].nodeName.toLowerCase()) !== -1
        ) {
          riskyElements.push(mutationNodes[j]);
        }
      }

      setTimeout(timerCallback, 200, riskyElements);
    }
  }

  let observer = new MutationObserver(initCallback);
  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });
  init(null);

})();