// ==UserScript==
// @name         Youtube To MP3 Button - Fast direct download without leaving the YouTube page!
// @namespace    https://greasyfork.org/en/users/665581-thedjchi
// @version      1.0
// @description  Convert YouTube videos to MP3 files without any external sites! Simply click the button and the download will begin automatically.
// @author       thedjchi
// @match        *://*.youtube.com/*
// ==/UserScript==

(function() {
    'use strict';

    //Checks if the new YouTube interface is being used
    if (document.getElementById("polymer-app") || document.getElementById("masthead") || window.Polymer) {
        setInterval(function() {
            //Checks if the current page is a video
            if (window.location.href.indexOf("watch?v=") < 0) {
                return false;
            }
            //Checks if there's already a YouTube to MP3 button created
            if (document.getElementById("count") && document.getElementById("ytmp3_btn") === null) {
                addButton();
            }
        }, 100);
    }

    function addButton () {

        var audioButtonDiv = document.createElement("span"); //Creates a container for the button
        audioButtonDiv.style.width = "100%"; //The width of the container
        audioButtonDiv.id = "ytmp3_btn"; //The container's unique ID
        var audioButton = document.createElement("a"); //Creates a link element for the button
        audioButton.appendChild(document.createTextNode("MP3")); //The text displayed on the button
        audioButton.style.width = "100%"; //THe width of the button
        audioButton.style.backgroundColor = "#c00"; //The color of the button's background
        audioButton.style.color = "white"; //The color of the button's text
        audioButton.style.textAlign = "center"; //The alignment of the button's text
        audioButton.style.padding = "1px 10px"; //The padding around the button's text
        audioButton.style.margin = "0px 10px"; //The spacing between the video's upload date and the button
        audioButton.style.fontSize = "14px"; //The font size of the button's text
        audioButton.style.border = "0"; //The thickness of the button's border
        audioButton.style.cursor = "pointer"; //The cursor icon used when hovering over the button
        audioButton.style.borderRadius = "2px"; //The corner radius of the button
        audioButton.style.fontFamily = "Roboto, Arial, sans-serif"; //The font used for the button's text

        //Places the button next to the video's upload date
        audioButtonDiv.appendChild(audioButton);
        var audioTargetElement = document.querySelectorAll("[id='date']");
        for (var i = 0; i < audioTargetElement.length; i++) {
            if (audioTargetElement[i].className.indexOf("ytd-video-primary-info-renderer") > -1) {
                audioTargetElement[i].appendChild(audioButtonDiv);
            }

        }

        //Adds a click function to the button that downloads the requested file
        audioButton.addEventListener("click", addLink, false);

        function addLink () {

            //Retrieves the video's unique ID
            var reg = new RegExp( '(?<=v=)[^&#]*', 'i' );
            var videoID = reg.exec(window.location.href);

            //Retrieves the title of the video
            var title = document.getElementsByClassName("title style-scope ytd-video-primary-info-renderer")[0].innerText;

            //Creates an API endpoint based on the ID and title of the video
            var endpoint = "https://yt-mp3-cors.herokuapp.com/https://api.youtube-mp3.org.in/@audio/" + videoID + "/?title=" + encodeURIComponent(title);

            //Sends an HTTP request using the API endpoint
            var request = new XMLHttpRequest();
            request.open("GET", endpoint);
            request.send();

            //Waits for the response data to be fully retrieved
            request.onload = function download () {

                //Retrieves the response text from the API
                var response = request.responseText;

                //Retrieves the download URL for the video's MP3 file
                var reg2 = new RegExp( '(?<=url": ").*(?=")', 'i' );
                var downloadURL = reg2.exec(response);

                //Downloads the reuqested MP3 file
                window.open(downloadURL, "_top");

            }

        }

    }

})();