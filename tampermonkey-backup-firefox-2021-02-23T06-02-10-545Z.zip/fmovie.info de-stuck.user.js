// ==UserScript==
// @name         fmovie.info de-stuck
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://fmovie.info/watch-free/*
// @grant        none
// ==/UserScript==

//setTimeout(function() {
//    var link = document.querySelector('#pop-preroll-close');
//    if(link) {
//        link.click();
//    }
////1-second delay
//}, 14000);


//setTimeout(function() {
//    document.querySelector('#buy-now').click()
//}, 1000)

setTimeout(function() {
    document.querySelector('#pop-preroll-close').click()

    //1-second delay
}, 24000);


