// ==UserScript==
// @author Newonroad
// @name PornHub Download Link Extractor
// @namespace newonroad
// @description Add download links with resolutions next to the "Jump to" button. Use save as... to download the video you need.
// @include     https://*.pornhub.com/view_video.php*
// @include     https://pornhub.com/view_video.php*
// @version     0.0.1
// @grant none
// ==/UserScript==

var playerElement = document.getElementById('player');
var videoId = "flashvars_" + playerElement.dataset.videoId;
var mediaDefinitions = window[videoId].mediaDefinitions;
var videoTabSize = 0;
mediaDefinitions.forEach(mediaDefinition => {
    if (mediaDefinition.videoUrl !== "") {
        var customDiv = document.createElement('div');
        customDiv.className = 'tab-menu-wrapper-cell';
        customDiv.innerHTML = '<div class="tab-menu-item tooltipTrig"  data-title="Download ' + mediaDefinition.quality + '"><i class="main-sprite-dark-2"></i><a download="' + document.title + '.mp4" target="_blank" href="' + mediaDefinition.videoUrl + '"><span>' + mediaDefinition.quality + '</span></a></div>';
        document.getElementsByClassName('tab-menu-wrapper-row')[0].appendChild(customDiv);
        videoTabSize++;
    }
});
var jsShareData = document.getElementById('js-shareData');
jsShareData.style.width = (jsShareData.offsetWidth + (80 * videoTabSize)).toString(10) + 'px';
