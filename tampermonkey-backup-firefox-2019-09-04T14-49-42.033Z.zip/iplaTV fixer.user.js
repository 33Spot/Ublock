// ==UserScript==
// @name         iplaTV fixer
// @namespace    http://tampermonkey.net/
// @version      0.1
// @require  http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js
// @require  https://gist.github.com/raw/2625891/waitForKeyElements.js
// @description  try to take over the world!
// @author       You
// @match        https://www.ipla.tv/wideo/*
// @grant        none
// ==/UserScript==

setTimeout(function() {
    'use strict';

    //document.getElementById("btnSimilar").click();
    document.querySelector('#cpp2-button button--1T5bc cpp2-round-button round-button--Rk7lt cpp2-fullscreen-on-button fullscreen-on-button--3RIuM').click()
    document.querySelector('#cpp2-button button--1T5bc cpp2-round-button round-button--Rk7lt cpp2-fullscreen-off-button fullscreen-off-button--2ccNB').click()



//waitForKeyElements ("a.class:contains('fullscreen-on-button')", clickOnFollowButton);
//waitForKeyElements ("a.class:contains('fullscreen-off-button')", clickOnFollowButton);

//function clickOnFollowButton (jNode) {
//    var clickEvent  = document.createEvent ('MouseEvents');
//    clickEvent.initEvent ('click', true, true);
//    jNode[0].dispatchEvent (clickEvent);
//}


}, 6000)();




//    document.getElementById("btn-fav").addEventListener("click", thumbClickHandler);
//    document.getElementById("player_ban").addEventListener("click", thumbClickHandler);
//    function thumbClickHandler() {
//        setMutationHandler(document, "input[type='submit']", function(observer, node) {
//            node.click();
//            observer.disconnect();
//        });
//    }
