// ==UserScript==
// @name         YouTube - アイコン画像を保存
// @namespace    http://tampermonkey.net/
// @version      1.0.0
// @license      MIT
// @description  YouTubeのチャンネルページでアイコン画像をクリックすると画像を保存するスクリプトです。
// @author       You
// @match        *://*.youtube.com/user/*
// @match        *://*.youtube.com/channel/*
// @match        *://*.youtube.com/c/*
// @grant        GM_download
// ==/UserScript==

(function() {
    'use strict';
    /*-------------------------------------------------- カスタマイズ領域 --------------------------------------------------*/
    // 保存時のファイル名のテンプレートを入力
    // 例: {channel_id} - {channel_name}
    // 利用できるテンプレート
    // channel_id ... チャンネルid
    // channel_name ... チャンネル名
    // year ... 年
    // month ... 月
    // date ... 日付
    // day ... 曜日
    // hours ... 時
    // minutes ... 分
    // seconds ... 秒
    // milliseconds ... ミリ秒
    // yymmdd ... yy-mm-dd形式の日付
    // hhmmss ... hh-mm-ss形式の時間
    var saveNameTemplate = "{channel_id} - {channel_name}";
    /*------------------------------------------------------------------------------------------------------------------*/
    // プライベート関数
    function _zeroPadding(str, len) { // 0埋めする
        return ("000" + str).slice(-len);
    };
    var icon = document.querySelector("#avatar img");
    icon.style.cursor = "pointer";
    icon.addEventListener("click", function(e) {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", e.target.src);
        xhr.onload = function() {
            GM_download({
                url: e.target.src,
                name: saveNameTemplate.replace(/\{[0-9a-z_]+\}/g, function(m) {
                    var now = new Date();
                    return ({ // テンプレートを置換
                        channel_id: document.querySelector("meta[itemprop='channelId']").content,
                        channel_name: document.querySelector("#text-container .ytd-channel-name").textContent,
                        year: now.getFullYear(),
                        month: _zeroPadding(now.getMonth(), 2),
                        date: _zeroPadding(now.getDate(), 2),
                        day: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][now.getDay()],
                        hours: _zeroPadding(now.getHours(), 2),
                        minutes: _zeroPadding(now.getMinutes(), 2),
                        seconds: _zeroPadding(now.getSeconds(), 2),
                        milliseconds: _zeroPadding(now.getMilliseconds(), 3),
                        yymmdd: now.getFullYear() + "-" + _zeroPadding(now.getMonth(), 2) + "-" + _zeroPadding(now.getDate(), 2),
                        hhmmss: _zeroPadding(now.getHours(), 2) + "-" + _zeroPadding(now.getMinutes(), 2) + "-" + _zeroPadding(now.getSeconds(), 2)
                    })[m.replace(/^{([0-9a-z_]+)}$/g, "$1")];
                }),
                saveAs: false,
                onload: function() {
                    console.log("保存完了");
                },
                onerror: function() {
                    console.log("保存失敗");
                },
                ontimeout: function() {
                    console.log("タイムアウト");
                }
            });
        };
        xhr.send();
    });
})();