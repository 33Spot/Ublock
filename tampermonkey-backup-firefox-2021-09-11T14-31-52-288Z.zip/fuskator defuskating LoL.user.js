// ==UserScript==
// @name         fuskator defuskating LoL
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  try to take over the world!
// @author       You
// @match        https://fuskator.com/expanded/*
// @match        https://fuskator.com/thumbs/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    document.getElementById("btnSimilar").click();
})();