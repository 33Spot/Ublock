// ==UserScript==
// @name            Pearson hide "Platform not supported"
// @author          Winston Weinert
// @namespace       https://winny.tech/
// @description     Put a good description in here
// @license         Creative Commons Attribution License
// @version	        0.1
// @include         https://*.pearsoned.com/*
// @include         https://*.ecollege.com/*
// @include         https://*.pearsonmylabandmastering.com/*
// @released        2020-04-05
// @updated         2020-04-05
// @compatible      Greasemonkey
// ==/UserScript==

(function(){
  var style = document.createElement("style");
  style.setAttribute('type', 'text/css');
  style.setAttribute('media', 'screen');
  style.appendChild(document.createTextNode('#browserCheckerMessage { display: none }'));
  document.getElementsByTagName('head')[0].appendChild(style);
})();
