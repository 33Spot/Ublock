// ==UserScript==
// @name Enable Right Click | Reek
// @namespace O8MMlsFZ4aoOdcjB
// @description Enable right click on websites having disabled
// @version 1.0
// @license Creative Commons BY-NC-SA
// @encoding utf-8
// @icon http://www.gravatar.com/avatar/afb8376a9f634cd3501af4387de6425f.png
// @include http*://*
// ==/UserScript==

  // Enable right click
  unsafeWindow.document.oncontextmenu = null;