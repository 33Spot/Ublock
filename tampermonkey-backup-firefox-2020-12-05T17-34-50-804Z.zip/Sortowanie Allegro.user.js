// ==UserScript==
// @name         Sortowanie Allegro
// @namespace    http://allegro.pl
// @version      1.2
// @description  Skrypt automatycznie zmienia sortowanie na: cena z dostawą: od najniższej
// @author       DD7
// @match        *://allegro.pl/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

const category = 'order=d',
	  url = window.location.toString();

if((url.includes('listing') || url.includes('kategoria') || url.includes('uzytkownik')) && !url.includes(category) ) {
	if(url.includes('order=')) return;

	if(!url.includes('?')) {
	   	window.location += `?&${category}`;
		return;
	}

	window.location += `&${category}`;
}