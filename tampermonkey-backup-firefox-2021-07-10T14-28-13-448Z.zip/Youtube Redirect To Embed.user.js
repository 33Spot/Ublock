// ==UserScript==
// @name         Youtube Redirect To Embed
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  youtube to embed
// @author       Shubham Kamthania
// @match        https://www.youtube.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    var goTOEmbed= function(){
        var parameters = new URLSearchParams(window.location.search);
        var videoCode = parameters.get('v');
        if(videoCode) {
            location.replace ("https://www.youtube.com/embed/" + videoCode);
        }
    }
    window.document.body.addEventListener("yt-navigate-finish", function(event) {
        goTOEmbed();
    });
    goTOEmbed();
})();