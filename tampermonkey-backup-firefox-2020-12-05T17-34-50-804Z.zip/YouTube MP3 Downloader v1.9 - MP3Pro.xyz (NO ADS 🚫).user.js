// ==UserScript==
// @name YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:pt-BR YouTube MP3 Downloader v1.9 - MP3Pro.xyz (SEM ANÚNCIOS 🚫)
// @name:ar YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:bg YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:cs YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:da YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:de YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:el YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:eo YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:es YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:fi YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:fr YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:fr-CA YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:he YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:hu YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:id YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:it YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:ja YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:ko YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:nb YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:nl YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:pl YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:ro YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:ru YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:sk YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:sr YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:sv YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:th YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:tr YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:uk YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:vi YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:zh-CN YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @name:zh-TW YouTube MP3 Downloader v1.9 - MP3Pro.xyz (NO ADS 🚫)
// @description Compatible with YouTube Multi Downloader! This script adds a download button, a faster way to download audio from YouTube and with guaranteed quality. This site is very simple, fast and effective to download! Best of all!
// @description:pt-BR Compatível com o YouTube Multi Downloader! Esse script adiciona um botão de download, uma maneira mais rápida de baixar áudio do YouTube e com qualidade garantida. Este site é muito simples, rápido e eficaz para baixar! Melhor de todos!
// @description:ar متوافق مع برنامج YouTube Multi Downloader! يضيف هذا البرنامج النصي زر تنزيل ، وهو طريقة أسرع لتنزيل الصوت من YouTube بجودة مضمونة. هذا الموقع بسيط جدا وسريع وفعال للتحميل! أفضل للجميع!
// @description:bg Съвместим с YouTube Multi Downloader! Този скрипт добавя бутон за изтегляне, по-бърз начин за изтегляне на аудио от YouTube и с гарантирано качество. Този сайт е много прост, бърз и ефективен за изтегляне! Най-добър от всички!
// @description:cs Kompatibilní s YouTube Multi Downloader! Tento skript přidává tlačítko stahování, rychlejší způsob stahování zvuku z YouTube a se zaručenou kvalitou. Tato stránka je velmi jednoduchá, rychlá a efektivní ke stažení! Nejlepší ze všech!
// @description:da Kompatibel med YouTube Multi Downloader! Dette script tilføjer en download-knap, en hurtigere måde at downloade lyd fra YouTube og med garanteret kvalitet. Denne side er meget enkel, hurtig og effektiv at downloade! Bedst af alt!
// @description:de Kompatibel mit YouTube Multi Downloader! Dieses Skript fügt eine Schaltfläche zum Herunterladen hinzu, eine schnellere Möglichkeit zum Herunterladen von Audio von YouTube und mit garantierter Qualität. Diese Seite ist sehr einfach, schnell und effektiv herunterzuladen! Am allerbesten!
// @description:el Συμβατό με το YouTube Multi Downloader! Αυτό το σενάριο προσθέτει ένα κουμπί λήψης, έναν πιο γρήγορο τρόπο λήψης ήχου από το YouTube και με εγγυημένη ποιότητα. Αυτός ο ιστότοπος είναι πολύ απλός, γρήγορος και αποτελεσματικός στη λήψη! Καλύτερο από ολα!
// @description:eo Kongrua kun YouTube Multi Downloader! Ĉi tiu skripto aldonas elŝutan butonon, pli rapidan manieron elŝuti audio de YouTube kaj kun garantiita kvalito. Ĉi tiu retejo estas tre simpla, rapida kaj efika elŝutebla! Plej bona el ĉiuj!
// @description:es Compatible con YouTube Multi Downloader! Este script agrega un botón de descarga, una forma más rápida de descargar audio de YouTube y con calidad garantizada. ¡Este sitio es muy simple, rápido y efectivo para descargar! ¡Mejor de todo!
// @description:fi Yhteensopiva YouTube Multi Downloader -sovelluksen kanssa! Tämä skripti lisää latauspainikkeen, nopeamman tavan ladata ääntä YouTubesta taatulla laadulla. Tämä sivusto on erittäin yksinkertainen, nopea ja tehokas ladata! Kaikkein paras!
// @description:fr Compatible avec YouTube Multi Downloader! Ce script ajoute un bouton de téléchargement, un moyen plus rapide de télécharger de l'audio à partir de YouTube et avec une qualité garantie. Ce site est très simple, rapide et efficace à télécharger! Le meilleur de tous!
// @description:fr-CA Compatible avec YouTube Multi Downloader! Ce script ajoute un bouton de téléchargement, un moyen plus rapide de télécharger de l'audio à partir de YouTube et avec une qualité garantie. Ce site est très simple, rapide et efficace à télécharger! Le meilleur de tous!
// @description:he תואם ל- YouTube Multi Downloader! סקריפט זה מוסיף לחצן הורדה, דרך מהירה יותר להורדת שמע מיוטיוב ובאיכות מובטחת. אתר זה פשוט מאוד, מהיר ויעיל להורדה! הטוב מכולם!
// @description:hu Kompatibilis a YouTube Multi Downloader szolgáltatással! Ez a szkript hozzáad egy letöltőgombot, a hangok gyorsabb letöltésének módját a YouTube-ról, garantált minőséggel. Ez az oldal nagyon egyszerű, gyors és hatékony letöltésre alkalmas! A legjobb!
// @description:id Kompatibel dengan YouTube Multi Downloader! Skrip ini menambahkan tombol unduh, cara yang lebih cepat untuk mengunduh audio dari YouTube dan dengan kualitas terjamin. Situs ini sangat sederhana, cepat dan efektif untuk diunduh! Terbaik dari semuanya!
// @description:it Compatibile con YouTube Multi Downloader! Questo script aggiunge un pulsante di download, un modo più veloce per scaricare audio da YouTube e con qualità garantita. Questo sito è molto semplice, veloce ed efficace da scaricare! Meglio di tutto!
// @description:ja YouTubeマルチダウンローダーと互換性があります！このスクリプトは、ダウンロードボタンを追加します。これは、YouTubeからオーディオをダウンロードするためのより高速な方法であり、品質が保証されています。このサイトは非常にシンプルで、高速で、ダウンロードが効率的です！最高のは！
// @description:ko YouTube Multi Downloader와 호환됩니다! 이 스크립트에는 다운로드 버튼이 추가되어 YouTube에서 오디오를보다 빠르게 다운로드하고 품질을 보장합니다. 이 사이트는 다운로드가 매우 간단하고 빠르고 효과적입니다! 무엇보다도!
// @description:nb Kompatibel med YouTube Multi Downloader! Dette skriptet legger til en nedlastningsknapp, en raskere måte å laste ned lyd fra YouTube og med garantert kvalitet. Dette nettstedet er veldig enkelt, raskt og effektivt å laste ned! Best av alt!
// @description:nl Compatibel met YouTube Multi Downloader! Dit script voegt een downloadknop toe, een snellere manier om audio van YouTube te downloaden en met gegarandeerde kwaliteit. Deze site is heel eenvoudig, snel en effectief om te downloaden! Beste van alles!
// @description:pl Kompatybilny z YouTube Multi Downloader! Ten skrypt dodaje przycisk pobierania, szybszy sposób pobierania dźwięku z YouTube i gwarantowaną jakość. Ta strona jest bardzo prosta, szybka i skuteczna do pobrania! Najlepszy ze wszystkich!
// @description:ro Compatibil cu YouTube Multi Downloader! Acest script adaugă un buton de descărcare, o modalitate mai rapidă de a descărca audio de pe YouTube și cu o calitate garantată. Acest site este foarte simplu, rapid și eficient de descărcat! Cel mai bun din toate!
// @description:ru Совместим с YouTube Multi Downloader! Этот скрипт добавляет кнопку загрузки, более быстрый способ загрузки аудио с YouTube и с гарантированным качеством. Этот сайт очень простой, быстрый и эффективный для скачивания! Лучше всех!
// @description:sk Kompatibilné s aplikáciou YouTube Multi Downloader! Tento skript pridáva tlačidlo sťahovania, rýchlejší spôsob sťahovania zvuku z YouTube a so zaručenou kvalitou. Tieto stránky je možné stiahnuť veľmi jednoducho, rýchlo a efektívne! Najlepší zo všetkých!
// @description:sr Kompatibilno je s YouTube Multi Downloader! Ova skripta dodaje gumb za preuzimanje, brži način za preuzimanje zvuka s YouTubea i uz zajamčenu kvalitetu. Ova stranica je vrlo jednostavna, brza i učinkovita za preuzimanje! Najbolje od svega!
// @description:sv Kompatibel med YouTube Multi Downloader! Detta skript lägger till en nedladdningsknapp, ett snabbare sätt att ladda ner ljud från YouTube och med garanterad kvalitet. Denna webbplats är mycket enkel, snabb och effektiv att ladda ner! Bäst av alla!
// @description:th เข้ากันได้กับ YouTube Multi Downloader! สคริปต์นี้เพิ่มปุ่มดาวน์โหลดวิธีที่เร็วกว่าในการดาวน์โหลดไฟล์เสียงจาก YouTube และรับประกันคุณภาพ เว็บไซต์นี้เรียบง่ายรวดเร็วและมีประสิทธิภาพในการดาวน์โหลด! ดีที่สุด!
// @description:tr YouTube Multi Downloader ile uyumlu! Bu komut dosyası bir indirme düğmesi, YouTube'dan ses indirmek için daha hızlı bir yol ve garantili kalite ekler. Bu siteyi indirmek çok basit, hızlı ve etkilidir! Hepsinin en iyisi!
// @description:uk Сумісний з YouTube Multi Downloader! Цей сценарій додає кнопку завантаження, більш швидкий спосіб завантаження аудіо з YouTube та гарантовану якість. Цей сайт дуже простий, швидкий та ефективний для завантаження! Найкращий!
// @description:vi Tương thích với YouTube Multi Downloader! Tập lệnh này thêm nút tải xuống, cách nhanh hơn để tải xuống âm thanh từ YouTube và với chất lượng được đảm bảo. Trang web này rất đơn giản, nhanh chóng và hiệu quả để tải về! Tốt nhất của tất cả!
// @description:zh-CN 与YouTube Multi Downloader兼容！该脚本添加了一个下载按钮，这是一种从YouTube下载音频且质量有保证的更快方法。这个网站非常简单，快速，有效地下载！最好的！
// @description:zh-TW 與YouTube Multi Downloader兼容！該腳本添加了一個下載按鈕，這是一種從YouTube下載音頻且質量有保證的更快方法。這個網站非常簡單，快速，有效地下載！最好的！
// @namespace https://greasyfork.org/users/152924
// @homepageURL https://greasyfork.org/scripts/376246
// @supportURL https://greasyfork.org/scripts/376246/feedback
// @author Punisher
// @version 1.9
// @date 2020-06-09
// @icon https://i.imgur.com/xLl6DWY.png
// @compatible chrome
// @compatible firefox
// @compatible opera
// @compatible safari
// @license CC BY-NC-ND 4.0 International. https://creativecommons.org/licenses/by-nc-nd/4.0/
// @match *://*.youtube.com/*
// ==/UserScript==

(function() {
    if (document.getElementById("polymerx-app") || document.getElementById("masthead") || window.Polymerx) {
    setInterval(function() {
        if (window.location.href.indexOf("watch?v=") < 0) {
            return false;
        }
        if (document.getElementById("meta-contents") && document.getElementById("punisherx") === null) {
            Addytpolymerx();
        }
    }, 100);

    setElement = function(url) {
       var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
       var match = String(url).match(regExp);
       return (match&&match[7].length==11)? match[7]: false;
    };

} else {

    setInterval(function() {
        if (window.location.href.indexOf("watch?v=") < 0) {
            return false;
        }
        if (document.getElementById("watch8-sentiment-actions") && document.getElementById("punisherx") === null) {
            AddhtmlDV();
        }
    }, 100);

    setElement = function(url) {
       var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
       var match = String(url).match(regExp);
       return (match&&match[7].length==11)? match[7]: false;
    };
}

function AddhtmlDV() {
    if (document.getElementById("watch8-sentiment-actions")) {
        var wrap = document.getElementById('watch8-sentiment-actions');
        var button = "<div id='punisherx' style='display: inline-block; margin-left: 5px; vertical-align: middle;'>";
        button += "<a href=\"//mp3pro.xyz/" + encodeURIComponent(setElement(window.location)) + "\" target=\"_blank\"" + "style=\"display: inline-block; font-size: inherit; height: inherit; border: 1px solid rgb(226, 226, 226); border-radius: 3px; padding-left: 28px; cursor: pointer; vertical-align: middle; position: relative; line-height: 22px; text-decoration: none; z-index: 1; color: rgb(226, 226, 226);\">";
        button += "<i style=\"position: absolute; display: inline-block; left: 6px; top: 3px; background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACLklEQVR42mNgAIKz8fFpR5KSeEHsSZ6e7CD6dExM8KmICCtkMawApHF7f//3PY2Nz09HRBiCxEJDQ5n3V1ff2Tphwo9ziYmZeA3ZGRvLfTYqyvhsUlLprvb2d6fj45NB4gcrKq6dS0oq2ldX9+hEVtZikNjMtDTW////M+J0zamoKJddbW3vzqSkNB0qLT17NjbWF2Qz0DV3jxQVHYGpA7kQrglk4qGgIEmYE4+Fhkrvq6m5D9K0KjSUE2Yj0IDDYIOgYQVyDcTWiAjZA1VVN0CmIpt8pLj4+MHy8svITj6VlTV/T3Pzq3MRESbwcDkeEaEA9OdDmGZkg47l5GzY09T0AugqFZghoHDZ1dHx4XRcXBJY4GhQkPyB2tp7KP5CCvVTiYklu9va3p6JinIEeQkc7dHRFkCDX55KS+uBuADoZ1wGnElISAXZeDE21glmwJnISI3dTU2vgAZMxDAA5GdYAIH8vLu19c2Z6GhdmMGnY2Njd3Z0fDwVH18AFkA2AKQZ7v/Cwj0gcVCowwLyVEpKOyitnIuL80QNRKBCmPNgiehAZeV15Og6np29GhSgwLSihBKNoEAEpTZYlIIUnczKWgp0wd5T0dF+4CgtKTm1v6rqNsx1cM3QhKNyqLLyKigVgkIbHDBAAEwbN0EGgOQOFxUdg4UPemAz7AkMFN7R0/MFlIRh+QBkAyjVgTLTqYyMWQTzwbHc3M2nIiPtYZkL7J309KmnU1IaCGVnAGSMRmieJSPHAAAAAElFTkSuQmCC); background-size: 12px; background-repeat: no-repeat; background-position: center center; width: 16px; height: 16px;\"></i>";
        button += "<span style=\"padding-right: 12px;\">Download MP3</span></a></div>";
        var style = "<style>#punisherx button: -moz-focus-inner {padding: 0; margin:0} #punisherx a {background-color: #1A1616} #punisherx a:hover {background-color: #1A1616} #punisherx a:active {background-color: #1A1616}</style>";
        var tmp = wrap.innerHTML;
        wrap.innerHTML = tmp + button + style;
    }
}

function Addytpolymerx() {
    var buttonDiv = document.createElement("span");
    buttonDiv.id = "punisherx";
    buttonDiv.style.width = "100%";
    buttonDiv.style.marginTop = "3px";
    buttonDiv.style.padding = "12px 0";
    var addButton = document.createElement("a");
    addButton.appendChild(document.createTextNode("DOWNLOAD MP3"));
    addButton.style.width = "100%";
    addButton.style.cursor = "pointer";
    addButton.style.height = "inherit";
    addButton.style.backgroundColor = "#141111";
    addButton.style.color = "#ffffff";
    addButton.style.padding = "10px 22px";
    addButton.style.margin = "0px 0px";
    addButton.style.border = "0";
    addButton.style.borderRadius = "2px";
    addButton.style.fontSize = "1.4rem";
    addButton.style.fontFamily = "inherit";
    addButton.style.textAlign = "center";
    addButton.style.textDecoration = "none";
    addButton.href = "//mp3pro.xyz/" + encodeURIComponent(setElement(window.location));
    addButton.target = "_blank";
    buttonDiv.appendChild(addButton);

    var targetElement = document.querySelectorAll("[id='subscribe-button']");
    if(targetElement){
      for(var i = 0; i < targetElement.length; i++){
        if(targetElement[i].className.indexOf("ytd-video-secondary-info-renderer") > -1){
            targetElement[i].appendChild(buttonDiv);
        }
      }
    }
}
})();