// ==UserScript==
// @name         YouTube - アイコン画像を保存
// @namespace    http://tampermonkey.net/
// @version      2.0.3
// @license      MIT
// @description  YouTubeのチャンネルページでアイコン画像をクリックすると画像を保存できるスクリプトです。
// @author       You
// @match        *://*.youtube.com/user/*
// @match        *://*.youtube.com/channel/*
// @match        *://*.youtube.com/c/*
// @icon         https://www.youtube.com/s/desktop/fe7279a7/img/favicon_144.png
// @grant        GM_download
// ==/UserScript==

'use strict'
/*-------------------------[ カスタマイズ領域 ]-------------------------*/
/*
 * 保存時のファイル名のテンプレートを入力
 * 例:
 * {channel.id} - {channel.username} --> UCxxxxxxxxxxxxxxxxxxxxxx - xxxxxx
 * {asset.yymmdd} {asset.hhmmss}-{date.milliseconds} --> xxxx-xx-xx xx-xx-xx-xxx
 *
 * channel
 *  - id | チャンネルid
 *  - username | チャンネル名
 * date
 *  - year | 年
 *  - month | 月
 *  - date | 日付
 *  - day | 曜日
 *  - hours | 時
 *  - minutes | 分
 *  - seconds | 秒
 *  - milliseconds | ミリ秒
 * asset
 *  - yymmdd | yy-mm-dd 形式の日付
 *  - hhmmss | hh-mm-ss 形式の時刻
 */
const FILENAME_TEMPLATE = '{channel.id} - {channel.username}'
/*
 * 保存時のファイルのサイズ[整数]
 */
const FILE_SIZE = 88
/*---------------------------------------------------------------------*/

// 定数
const USERSCRIPT_NAME = 'YouTube - アイコン画像を保存'

// メイン
const main = async () => {
    const cover = document.createElement('div'),
        coverCls = 'userscript-' + Array.from(new Uint8Array(await crypto.subtle.digest(
            'SHA-256',
            new TextEncoder().encode(Date.now().toString())
        ))).map(n => n.toString(16).padStart(2, '0')).join('')
    cover.classList.add(coverCls)
    const icon = document.getElementById('channel-header-container').getElementsByTagName('img')[0]
    icon.parentNode.insertBefore(cover, icon)
    const style = document.createElement('style')
    style.textContent = `.${coverCls} { width: ${icon.offsetWidth}px; height: ${icon.offsetWidth}px; position: fixed; border-radius: 50% }`
        + ` .${coverCls}:hover { display: flex; justify-content: center; align-items: center; cursor: pointer; background-color: rgba(255, 255, 255, 0.5) }`
        + ` .${coverCls}:hover::before { content: "保存"; font-size: 12px }`
    document.head.appendChild(style)
    cover.addEventListener('click', async e => {
        const body = await (await fetch(location.href)).text()

        const [temp_userId, temp_username] = body.match(/"channelId":"([\w\-]+)","title":"([^"]*?)"/).slice(1).map(v => v.replace(/\\u[0-9a-z]{4}/g, u => String.fromCodePoint(Number(u.replace(/^\\u/, '0x'))))),
            now = new Date(),
            temp_yymmdd = [now.getFullYear(), now.getMonth() + 1, now.getDate()]
                .map((v, i) => i > 0 ? v.toString().padStart(2, '0') : v),
            temp_hhmmss = now.toString().match(/\d{2}:\d{2}:\d{2}/)[0].split(':'),
            temp_day = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][now.getDay()],
            temp_milliseconds = now.toISOString().match(/\.(\d{3})Z$/)[1]

        GM_download({
            url: e.target.nextElementSibling.getAttribute('src')
                .replace(/=s88-/, `=s${FILE_SIZE}-`),
            name: FILENAME_TEMPLATE.replace(/\{.*?\}/g, v => {
                const m = (v.match(/^\{([a-z]+(?:\.[a-z]+)?)\}$/) || [])[1]
                switch (m) {
                    case 'channel.id':
                        return temp_userId
                    case 'channel.username':
                        return temp_username
                    case 'date.year':
                        return temp_yymmdd[0]
                    case 'date.month':
                        return temp_yymmdd[1]
                    case 'date.date':
                        return temp_yymmdd[2]
                    case 'date.day':
                        return temp_day
                    case 'date.hours':
                        return temp_hhmmss[0]
                    case 'date.minutes':
                        return temp_hhmmss[1]
                    case 'date.seconds':
                        return temp_hhmmss[2]
                    case 'date.milliseconds':
                        return temp_milliseconds
                    case 'asset.yymmdd':
                        return temp_yymmdd.join('-')
                    case 'asset.hhmmss':
                        return temp_hhmmss.join('-')
                    default:
                        console.warn(`[${USERSCRIPT_NAME}]`, `無効なテンプレート\`${v}\`を空白として展開しました`)
                        return ''
                }
            }),
            saveAs: false,
            onload: () => console.log(`[${USERSCRIPT_NAME}]`, '保存完了'),
            onerror: e => console.error(`[${USERSCRIPT_NAME}]`, e),
            ontimeout: () => console.error(`[${USERSCRIPT_NAME}]`, 'タイムアウト')
        })
    })
}

// 実行
main().catch(console.error)