// ==UserScript==
// @name pornhub.com user videos link grabber
// @description This adds a button to pornhub user pages to download all videos
// @version 1.0.2
// @license MIT
// @grant GM_download
// @match https://pornhub.com/users/*/videos/public*
// @match https://*.pornhub.com/users/*/videos/public*
// @namespace https://greasyfork.org/users/179893
// ==/UserScript==

//TODO error handling with the promises. collect all errors and reattempt everyone once. display error on result page
//fancy: progress bar
//fancy: download manager like features: max 6 dls in parallel, the rest are queued. make that number configurable.

(function() {
  'use strict';

  var btnContainer = document.querySelector('.profileVids .spriteProfileIcons');

  var linkGrabberBtn = document.createElement('a');
  linkGrabberBtn.text = 'Get all video links';
  linkGrabberBtn.onclick = loadLinksAndOpenPanel;
  linkGrabberBtn.classList.add('greyButton');
  linkGrabberBtn.classList.add('float-right');
  btnContainer.appendChild(linkGrabberBtn);

  
  addcss(`.loader {
      position: absolute;
      left: 50%;
      top: 50%;
      z-index: 200;
      border: 16px solid #f3f3f3; /* Light grey */
      border-top: 16px solid #3498db; /* Blue */
      border-radius: 50%;
      width: 120px;
      height: 120px;
      margin: -60px 0 0 -60px;
      animation: spin 2s linear infinite;
    }

    @keyframes spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }`);



  function ShowLoader(){
    var loader = document.createElement('div');
    loader.id = 'myVeryOwnCustomLoaderUsingAnUniqueId'
    loader.className = 'loader';
    document.body.appendChild(loader);
  }

  function RemoveLoader(){
    var loader = document.getElementById('myVeryOwnCustomLoaderUsingAnUniqueId');
    if(loader){
      loader.parentNode.removeChild(loader);
    }
  }

  function loadLinksAndOpenPanel (){
    ShowLoader();
    if( location.hash && location.hash != ''){
      location.hash = '';
      location.href = location.href.slice(0,location.href.length-1);
      setTimeout(function () {
        clickMoreDataBtn();
      }, 1000);
    }else{
      clickMoreDataBtn();
    }
  }

  function clickMoreDataBtn(){
    var moreDataBtn = document.getElementById('moreDataBtn');
    if(moreDataBtn != null && (moreDataBtn.style.display!='none')){
      moreDataBtn.click();
      setTimeout(function () {
          clickMoreDataBtn();
        }, 1000);
    }else {
      var linkList = grabVideoList();
      RemoveLoader();
      showLinks(linkList);
    }
  }
  
  function grabVideoList(){
    var videoUList = document.getElementsByClassName('videoUList')[0];
    var linkList = videoUList.querySelectorAll('span > a');
    // for(var i = 0; i< linkList.length; i++){
    //   console.log(linkList[i].href);
    // }
    return linkList;
  }
  
  function showLinks(linkList){
    var outerModalDiv = document.createElement('div');
    var innerModalDiv = document.createElement('div');
    outerModalDiv.id = 'userVidsLinkContainingModalPanel'; //use a long id to avoid name conflicts
    outerModalDiv.style.display = 'block';
    outerModalDiv.style.position = 'fixed';
    outerModalDiv.style.zIndex = '100';
    outerModalDiv.style.paddingTop = '100px';
    outerModalDiv.style.left = '0';
    outerModalDiv.style.top = '0';
    outerModalDiv.style.width = '100%';
    outerModalDiv.style.height = '100%';
    outerModalDiv.style.overflow = 'auto';
    outerModalDiv.style.backgroundColor = 'rgb(0,0,0)';
    outerModalDiv.style.backgroundColor = 'rgb(0,0,0,0.4)';

    //add close btn
    var closeButtonContainer = document.createElement('div');
    closeButtonContainer.className = 'userButtons';
    var closeButton = CreateButton('X', null, RemoveOuterModalPanel);
    closeButton.style.cssFloat = 'right';
    closeButtonContainer.appendChild(closeButton);
    innerModalDiv.appendChild(closeButtonContainer);
    
  
    innerModalDiv.style.backgroundColor = '#1b1b1b';
    innerModalDiv.style.margin = 'auto';
    innerModalDiv.style.padding = '20px';
    innerModalDiv.style.border = '1px solid #888';
    innerModalDiv.style.width = '80%';
    innerModalDiv.style.color = '#ababab';
  
    var instructions1 = document.createElement('p');
    var instructions2 = document.createElement('p');
    var instructions3 = document.createElement('p');
    var instructions4 = document.createElement('p');

    instructions1.innerHTML = 'Save the links to a local textfile (e.g. &quotC:\\Temp\\dl\\linklist.txt)&quot and run youtube-dl whith the -a argument and the path to the linklist.';
    instructions2.innerHTML = 'youtube-dl -a &quotC:\\Temp\\dl\\linklist.txt&quot';
    instructions3.innerHTML = 'Or just use jDownloader with the linklist';
    instructions4.innerHTML = 'Or use the button below to trigger the download of all links within your browser';

    innerModalDiv.appendChild(instructions1);
    innerModalDiv.appendChild(instructions2);
    innerModalDiv.appendChild(instructions3);
    innerModalDiv.appendChild(instructions4);
  

    var linkListDiv;

    //add dl button
    var dlButtonContainer = document.createElement('div');
    dlButtonContainer.className = 'userButtons';
    dlButtonContainer.style.marginBottom = '10px';


    var resolveButton = CreateButton('resolve links', null, function(event){
      event.stopPropagation();
      ResolveLinks(linkListDiv.childNodes);
    });
    resolveButton.style.cssFloat = 'left';
    resolveButton.style.marginRight = '5px';
    dlButtonContainer.appendChild(resolveButton);

    var dlButton = CreateButton('download all', 'TheOneAndOnlyDownloadAllButton', function(event){
      event.stopPropagation();
      DownloadAll(linkListDiv.childNodes);
    });
    dlButton.style.visibility = 'hidden';
    dlButtonContainer.appendChild(dlButton);

    innerModalDiv.appendChild(dlButtonContainer);

    linkListDiv = document.createElement('div');


    for(var i = 0; i < linkList.length; i++){
      var a = document.createElement('a');
      var p = document.createElement('p');
      p.innerHTML = linkList[i].href;
      a.href = linkList[i].href;
      a.download = linkList[i].title;
      a.appendChild(p);
      linkListDiv.appendChild(a);
    }
    innerModalDiv.appendChild(linkListDiv);
    outerModalDiv.appendChild(innerModalDiv);
    document.body.appendChild(outerModalDiv);
  }

  function CreateButton(text, id, onClickEvent){
    var innerbutton = document.createElement('button');
    innerbutton.innerText = text;
    innerbutton.className = 'buttonBase';
    innerbutton.style.backgroundColor = '#f90';
    innerbutton.style.color = '#000';
    innerbutton.style.fontWeight = '700';
    innerbutton.display = 'inline-block';

    var button = document.createElement('div');
    if(id) button.id = id;
    
    button.style.padding = '5px 10px';
    button.style.lineHeight = '1.2em';
    button.style.borderRadius = '4px';
    button.onclick = onClickEvent;
    button.appendChild(innerbutton);
    return button;
  }

  function RemoveOuterModalPanel(){
    var toRemove = document.getElementById('userVidsLinkContainingModalPanel');
    toRemove.parentNode.removeChild(toRemove);
  }

  function addcss(css){
    var head = document.getElementsByTagName('head')[0];
    var s = document.createElement('style');
    s.setAttribute('type', 'text/css');
    if (s.styleSheet) {   // IE
        s.styleSheet.cssText = css;
    } else {                // the world
        s.appendChild(document.createTextNode(css));
    }
    head.appendChild(s);
 }


  function makeRequest (method, url, aElem) {
  return new Promise(function (resolve, reject) {
    var xhr = new XMLHttpRequest();
    xhr.open(method, url);
    xhr.responseType = 'document';
    xhr.onload = function () {
      if (this.status >= 200 && this.status < 300) {
        resolve([xhr.response, aElem]);
      } else {
        reject({
          status: this.status,
          statusText: xhr.statusText,
          aElem : aElem
        });
      }
    };
    xhr.onerror = function () {
      reject({
        status: this.status,
        statusText: xhr.statusText,
        aElem : aElem
      });
    };
    xhr.send();
  });
  }

 function ResolveLinks(links){
  ShowLoader();
  var newLinks = document.createElement('div');
  var promises = [];

  for(var i = 0; i < links.length; i++){

    if(links[i].dataset.resolved){
      console.log('skip link nr ' + i + " as it's resolved.");
      continue;
    }

    var url = links[i].href;

    promises.push(makeRequest('GET', url, links[i]).then(function(valueHolderArray){
      var response = valueHolderArray[0];
      var aElem = valueHolderArray[1];

      var scriptTag = response.querySelectorAll('div.wrapper div.container div#main-container div.video-wrapper div#player script')[0];
      var flashvarsRAW = scriptTag.innerHTML.match(/[^\r\n]+/g)[0];
      var rawJSON = flashvarsRAW.slice(flashvarsRAW.indexOf('{'),flashvarsRAW.length-1);
      var obj = JSON.parse(rawJSON);
      var defaultQualityVideoURL;
      obj.mediaDefinitions.forEach(function(element){
        if(element.defaultQuality){
          defaultQualityVideoURL = element.videoUrl;
        }
      });
      if(!defaultQualityVideoURL) {console.log('no default quality found');}
      
      var titleSpan = response.querySelector('h1.title span');
      var title = "couldn't resolve name";
      if(titleSpan){
        title = titleSpan.innerText;
      }

      aElem.href = defaultQualityVideoURL;
      aElem.download = title+'.mp4';
      aElem.dataset.resolved = true;
      while (aElem.firstChild) {
        aElem.removeChild(aElem.firstChild);
      }
      var p = document.createElement('p');
      p.innerText = title;
      aElem.appendChild(p);

    }).catch(function (err) {
      console.log(err);
      console.error('Augh, there was an error!', err.statusText, err.aElem);
    }));

    

  }
  Promise.all(promises).then(function(){
    RemoveLoader();
    document.getElementById('TheOneAndOnlyDownloadAllButton').style.visibility = 'visible';
  },function(){
    console.log('some promises were rejected.'); //what now?
    RemoveLoader();
  });
  // return newLinks;
 }

 function DownloadAll(links){
    for(var i = 0; i < links.length; i++){
      if(links[i].dataset.resolved){
        console.log('download ' + links[i].download);
        GM_download(links[i].href, links[i].download);
      }
    }
 }

})();