// ==UserScript==
// @name         pierdolic medonet
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        https://medonet.pl/*
// @match        https://www.medonet.pl/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    document.getElementsByClassName("medonet__healthcare__open").click();
    document.getElementsByClassName("medonet__healthcare__close").click();
})();