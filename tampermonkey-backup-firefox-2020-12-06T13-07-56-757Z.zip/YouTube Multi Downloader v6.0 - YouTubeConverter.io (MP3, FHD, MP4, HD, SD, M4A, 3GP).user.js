// ==UserScript==
// @name YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:pt-BR YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:ar YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:bg YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:cs YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:da YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:de YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:el YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:eo YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:es YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:fi YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:fr YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:fr-CA YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:he YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:hu YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:id YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:it YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:ja YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:ko YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:nb YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:nl YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:pl YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:ro YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:ru YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:sk YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:sr YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:sv YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:th YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:tr YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:uk YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:vi YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:zh-CN YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @name:zh-TW YouTube Multi Downloader v6.0 - YouTubeConverter.io (MP3, FHD, MP4, HD, SD, M4A, 3GP)
// @description Compatible with YouTube MP3 Downloader! This script helps to add a download button more quickly to download videos and audios from YouTube.
// @description:pt-BR Compatível com o YouTube MP3 Downloader! Esse script ajuda a adicionar um botão de download mais rapidamente para baixar vídeos e áudios do YouTube.
// @description:ar متوافق مع يوتيوب MP3 تنزيل! يساعد هذا البرنامج النصي على إضافة زر تنزيل بشكل أسرع لتنزيل مقاطع الفيديو والتسجيلات الصوتية من YouTube.
// @description:bg Съвместим с MP3 Downloader на YouTube! Този скрипт помага да добавите по-бързо бутон за изтегляне, за да изтеглите видеоклипове и аудио от YouTube.
// @description:cs Kompatibilní s YouTube MP3 Downloader! Tento skript pomáhá rychleji přidat tlačítko pro stahování videí a audia z YouTube.
// @description:da Kompatibel med YouTube MP3 Downloader! Dette script hjælper med at tilføje en download-knap hurtigere for at downloade videoer og audios fra YouTube.
// @description:de Kompatibel mit YouTube MP3 Downloader! Mit diesem Skript können Sie schneller eine Download-Schaltfläche hinzufügen, um Videos und Audios von YouTube herunterzuladen.
// @description:el Συμβατό με το YouTube MP3 Downloader! Αυτό το σενάριο βοηθά να προσθέσετε ένα κουμπί λήψης πιο γρήγορα για να κατεβάσετε βίντεο και ήχους από το YouTube.
// @description:eo Kongrua kun YouTube MP3 Downloader! Ĉi tiu skripto helpas aldoni elŝutan butonon pli rapide por elŝuti filmetojn kaj sonojn de YouTube.
// @description:es Compatible con YouTube MP3 Downloader! Este script ayuda a agregar un botón de descarga más rápidamente para descargar videos y audios de YouTube.
// @description:fi Yhteensopiva YouTube MP3 Downloader -sovelluksen kanssa! Tämä skripti auttaa lisäämään latauspainikkeen nopeammin videoiden ja äänien lataamiseen YouTubesta.
// @description:fr Compatible avec YouTube MP3 Downloader! Ce script permet d'ajouter un bouton de téléchargement plus rapidement pour télécharger des vidéos et des fichiers audio à partir de YouTube.
// @description:fr-CA Compatible avec YouTube MP3 Downloader! Ce script permet d'ajouter un bouton de téléchargement plus rapidement pour télécharger des vidéos et des fichiers audio à partir de YouTube.
// @description:he תואם להורדת MP3 של YouTube! סקריפט זה עוזר להוסיף לחצן הורדה במהירות רבה יותר להורדת סרטונים ושמעים מ- YouTube.
// @description:hu Kompatibilis a YouTube MP3 Downloader-rel! Ez a szkript segít a letöltési gomb gyorsabb hozzáadásában a videók és audiók letöltéséhez a YouTube-ról.
// @description:id Kompatibel dengan YouTube MP3 Downloader! Skrip ini membantu menambahkan tombol unduhan lebih cepat untuk mengunduh video dan audio dari YouTube.
// @description:it Compatibile con YouTube MP3 Downloader! Questo script aiuta ad aggiungere un pulsante di download più rapidamente per scaricare video e audio da YouTube.
// @description:ja YouTube MP3ダウンローダーと互換性があります！このスクリプトは、YouTubeからビデオやオーディオをダウンロードするためのダウンロードボタンをより迅速に追加するのに役立ちます。
// @description:ko YouTube MP3 다운로더와 호환! 이 스크립트는 YouTube에서 비디오 및 오디오를 다운로드하기 위해 다운로드 버튼을 더 빨리 추가하는 데 도움이됩니다.
// @description:nb Kompatibel med YouTube MP3 Downloader! Dette skriptet hjelper deg med å legge til en nedlastningsknapp raskere for å laste ned videoer og lydbånd fra YouTube.
// @description:nl Compatibel met YouTube MP3 Downloader! Dit script helpt om een downloadknop sneller toe te voegen om video's en audio van YouTube te downloaden.
// @description:pl Kompatybilny z YouTube MP3 Downloader! Ten skrypt pomaga szybciej dodać przycisk pobierania, aby pobierać filmy i pliki audio z YouTube.
// @description:ro Compatibil cu YouTube MP3 Downloader! Acest script vă ajută să adăugați mai rapid un buton de descărcare pentru a descărca videoclipuri și audio de pe YouTube.
// @description:ru Совместимо с YouTube MP3 Downloader! Этот скрипт помогает быстрее добавить кнопку загрузки для загрузки видео и аудио с YouTube.
// @description:sk Kompatibilné s aplikáciou YouTube na stiahnutie MP3! Tento skript pomáha rýchlejšie pridávať tlačidlo na sťahovanie videí a audia z YouTube.
// @description:sr Kompatibilan s YouTube MP3 Downloader-om! Ova skripta pomaže bržem dodavanju gumba za preuzimanje za preuzimanje videozapisa i audio zapisa s YouTubea.
// @description:sv Kompatibel med YouTube MP3 Downloader! Detta skript hjälper till att lägga till en nedladdningsknapp snabbare för att ladda ner videor och ljud från YouTube.
// @description:th เข้ากันได้กับ YouTube MP3 Downloader! สคริปต์นี้ช่วยเพิ่มปุ่มดาวน์โหลดได้เร็วขึ้นเพื่อดาวน์โหลดวิดีโอและไฟล์เสียงจาก YouTube
// @description:tr YouTube MP3 Downloader ile uyumlu! Bu komut dosyası, YouTube'dan video ve ses indirmek için bir indirme düğmesi daha hızlı eklemenize yardımcı olur.
// @description:uk Сумісний з YouTube MP3 Downloader! Цей сценарій допомагає швидше додати кнопку завантаження для завантаження відео та аудіо з YouTube.
// @description:vi Tương thích với YouTube MP3 Downloader! Kịch bản này giúp thêm nút tải xuống nhanh hơn để tải xuống video và âm thanh từ YouTube.
// @description:zh-CN 与YouTube MP3下载器兼容！该脚本有助于更快地添加下载按钮，以从YouTube下载视频和音频。
// @description:zh-TW 與YouTube MP3下載器兼容！該腳本有助於更快地添加下載按鈕，以從YouTube下載視頻和音頻。
// @namespace https://greasyfork.org/users/152924
// @homepageURL https://greasyfork.org/scripts/34613
// @supportURL https://greasyfork.org/scripts/34613/feedback
// @author Punisher
// @version 6.0
// @date 2020-07-27
// @icon https://i.imgur.com/InuDDVK.png
// @compatible chrome
// @compatible firefox
// @compatible opera
// @compatible safari
// @license CC BY-NC-ND 4.0 International. https://creativecommons.org/licenses/by-nc-nd/4.0/
// @match *://*.youtube.com/*
// ==/UserScript==

(function() {
    if (document.getElementById("polymerz-app") || document.getElementById("masthead") || window.Polymerz) {
    setInterval(function() {
        if (window.location.href.indexOf("watch?v=") < 0) {
            return false;
        }
        if (document.getElementById("meta-contents") && document.getElementById("punisherz") === null) {
            Addytpolymerz();
        }
    }, 100);

    setElement = function(url) {
       var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
       var match = String(url).match(regExp);
       return (match&&match[7].length==11)? match[7]: false;
    };

} else {

    setInterval(function() {
        if (window.location.href.indexOf("watch?v=") < 0) {
            return false;
        }
        if (document.getElementById("watch8-sentiment-actions") && document.getElementById("punisherz") === null) {
            AddhtmlDV();
        }
    }, 100);

    setElement = function(url) {
       var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
       var match = String(url).match(regExp);
       return (match&&match[7].length==11)? match[7]: false;
    };
}

function AddhtmlDV() {
    if (document.getElementById("watch8-sentiment-actions")) {
        var wrap = document.getElementById('watch8-sentiment-actions');
        var button = "<div id='punisherz' style='display: inline-block; margin-left: 5px; vertical-align: middle;'>";
        button += "<a href=\"//youtubeconverter.io/convert?query=" + encodeURIComponent(location.href) + "\" target=\"_blank\"" + "style=\"display: inline-block; font-size: inherit; height: inherit; border: 1px solid rgb(226, 226, 226); border-radius: 3px; padding-left: 28px; cursor: pointer; vertical-align: middle; position: relative; line-height: 22px; text-decoration: none; z-index: 1; color: rgb(226, 226, 226);\">";
        button += "<i style=\"position: absolute; display: inline-block; left: 6px; top: 3px; background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAA3UlEQVR42mNgoDX4//+/PhBHA7EnEHOSolEAiLf8RwL//v17DqRcCWkyBmJ2oOJN/7GDr0Csik2zG1DTZySb8IFJ2Aw4+594cASIGZE18wDxEzT/vgZSd0EYysZmiCBIsyMQv8CioAaIl0JxDQ6XLAAZ8B6HZDvIIVDcjk0B0GWfGKAKyDXgC8iAh2iCF4DUCSAuQDKgACp2EU3tclj0fUESBMV/ChAfQjIAxE5BSxvngVgMFgvSQJwKxIVQ2/SRFUPZ+lD5PCD2AWIWQkmZE2rzQZLyAJakLUDT3AoALzJfljL5Yb4AAAAASUVORK5CYII=); background-size: 12px; background-repeat: no-repeat; background-position: center center; width: 16px; height: 16px;\"></i>";
        button += "<span style=\"padding-right: 12px;\">Download</span></a></div>";
        var style = "<style>#punisherz button: -moz-focus-inner {padding: 0; margin:0} #punisherz a {background-color: #1A1616} #punisherz a:hover {background-color: #1A1616} #punisherz a:active {background-color: #1A1616}</style>";
        var tmp = wrap.innerHTML;
        wrap.innerHTML = tmp + button + style;
    }
}

function Addytpolymerz() {
    var buttonDiv = document.createElement("span");
    buttonDiv.id = "punisherz";
    buttonDiv.style.width = "100%";
    buttonDiv.style.marginTop = "3px";
    buttonDiv.style.padding = "12px 0";
    var addButton = document.createElement("a");
    addButton.appendChild(document.createTextNode("DOWNLOAD"));
    addButton.style.width = "100%";
    addButton.style.cursor = "pointer";
    addButton.style.height = "inherit";
    addButton.style.backgroundColor = "#141111";
    addButton.style.color = "#ffffff";
    addButton.style.padding = "10px 22px";
    addButton.style.margin = "0px 0px";
    addButton.style.border = "0";
    addButton.style.borderRadius = "2px";
    addButton.style.fontSize = "1.4rem";
    addButton.style.fontFamily = "inherit";
    addButton.style.textAlign = "center";
    addButton.style.textDecoration = "none";
    addButton.href = "//youtubeconverter.io/convert?query=" + encodeURIComponent(location.href);
    addButton.target = "_blank";
    buttonDiv.appendChild(addButton);

    var targetElement = document.querySelectorAll("[id='subscribe-button']");
    if(targetElement){
      for(var i = 0; i < targetElement.length; i++){
        if(targetElement[i].className.indexOf("ytd-video-secondary-info-renderer") > -1){
            targetElement[i].appendChild(buttonDiv);
        }
      }
    }
}
})();